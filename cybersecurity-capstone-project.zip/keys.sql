-- 
-- Table structure for table `keys`
-- 

CREATE TABLE 'messagekeys' (
  'user1' bigint(20) NOT NULL,
  'user2' bigint(20) NOT NULL,
  'mskey' varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
